import time
import random


def print_pause(message_to_print):
    print(message_to_print)
    time.sleep(0)


def intro():

    animal = ["dragon", "centurion", "phantom"]
    y = random.choice(animal)
    a = ("Somewhere in the campus everybody hears a strange sound made by a ")
    c = (" and all the students are very scared.")
    d = a+y+c
    print(d)
    print_pause("At your left is a chamber that makes strange noises.")
    print_pause("It seems that a strange creature wants to get out on campus.")
    print_pause("At your right is the director`s office. ")
    print_pause("Enter 1 to go approach the chamber door.")
    print_pause("Enter 2 to go in the director`s office.")


def intro_2():
    print_pause("Now you returned back in the hallway.")
    print_pause("The sounds from behind the door are getting closer.")
    print_pause("The creature sounds like it is getting close.r")
    print_pause("What do you want to do?")
    print_pause("Go to the door without the key (1)")
    print_pause("Go back to the office to get the key (2)")
    print_pause("Run away (3)")
    response = input()
    while (response != "1" and response != "2" and response != "3"):
        print_pause("Please choose only between 1, 2 or 3.")
        response = input()
    if "2" in response:
        print_pause("Now you go back to the director`s office.")
        office()
    elif "3" in response:
        print_pause("Sometime running is the best choice.")
        print_pause("Ruuuuuuun.")
        print_pause("You lost!")
        play_again()
    elif "1" in response:
        chamber("0")


def play_again():
    response = input("Do you want to play again?(Enter Y/N)").lower()
    while (response != "y" and response != "n"):
        print_pause("Please choose only y or n.")
        response = input()
    if "y" in response:
        intro()
        valid_input()
    elif "n" in response:
        print_pause("Bye Bye!")


def valid_input():
    print_pause("What would you like to do?")
    response = input()
    while (response != "1" and response != "2"):
        print_pause("Please choose only between 1 or 2")
        response = input()
    if "1" in response:
        print_pause("Slowly you approach the chamber`s door.")
        chamber("0")
    elif "2" in response:
        print_pause("Slowly you go into the directors office.")
        print_pause("Take care because is very dark inside.")
        print_pause("You are looking for the chamber`s key.")
        print_pause("In the drawer of the directors desk you find the key.")
        print_pause("Do you take it?")
        office()


def chamber(key):
    if key == "1":
        print_pause("You approach the door of the chamber.")
        print_pause("You are getting closer and closer.")
        print_pause("You open the door and you see the creature.")
        print_pause("It sees you and starts runnning to the door.")
        print_pause("The creature wants to attack you.")
        print_pause("What do you do?")
        response = input("(1) close the door or (2) run back?").lower()
        while (response != "1" and response != "2"):
            print_pause("Please choose only between 1 or 2.")
            response = input()
        if "1" in response:
            print_pause("You closed the door.")
            print_pause("The campus is safe. You are a hero!")
            play_again()
        elif "2" in response:
            print_pause("You ran and the campus is insecure. You lost!")
            play_again()
    elif key == "0":
        print_pause("You approach the door of the chamber.")
        print_pause("You are slowly getting really really close.")
        print_pause("You hear behind the door the creature approaching.")
        print_pause("You get an idea.")
        print_pause("If you run real quick you might still find the key.")
        print_pause("And close the creature in the chamber.")
        print_pause("Or you could run away?")
        print_pause("Or you could fight the creature?")
        print_pause("What do you do?")
        print_pause("(1) look for the key")
        print_pause("(2) run away")
        print_pause("(3) fight the creature")
        response = input().lower()
        while (response != "1" and response != "2" and response != "3"):
            print_pause("Please choose only between 1, 2 or 3.")
            response = input()
        if "1" in response:
            print_pause("Now you you ran real quick to the director`s office.")
            office()
        elif "2" in response:
            print_pause("Sometime running is the best choice.")
            print_pause("Ruuuuuuun!")
            print_pause("You lost!")
            play_again()
        elif "3" in response:
            print_pause("So you decided to fight.")
            print_pause("Get ready!")
            print_pause("The creature bursted through the door and killed you")
            print_pause("Sad.")
            print_pause("You lost!")
            play_again()


def go_back_to_chamber():
    print_pause("You approach the door of the chamber.")
    print_pause("You are about to get close from it.")
    print_pause("When in your front appear that strange creature.")
    print_pause("The creature is trying to attack you.")
    print_pause("Because you hadn`t the key to close the door,")
    print_pause("the creature is able to go out, you lost the battle.")
    play_again()


def office():
    print_pause("You are in the directors office and you find the key.")
    print_pause("Press (y) for taking the key or (n) to go back without it.")
    response = input().lower()
    while (response != "y" and response != "n"):
        print_pause("Please choose only y or n.")
        response = input()
    if "y" in response:
        print_pause("You took the key.")
        print_pause("And you return back to the hallway.")
        chamber("1")
    elif "n" in response:
        print_pause("You didn't take the key.")
        print_pause("And you return back to the hallway.")
        intro_2()


intro()
valid_input()
play_again()
